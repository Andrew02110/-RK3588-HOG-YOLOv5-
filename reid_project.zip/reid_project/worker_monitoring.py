import torch  # PyTorchÉî¶ÈÑ§Ï°¿ò¼Ü£¬ÓÃÓÚ¼ÓÔØ²¢ÔËÐÐYOLOv5Ä¿±ê¼ì²âÄ£ÐÍ
import cv2  # OpenCV¿â£¬ÓÃÓÚÍ¼Ïñ´¦ÀíºÍÉãÏñÍ·²Ù×÷
import time  # ÓÃÓÚÊ±¼äÏà¹Ø²Ù×÷
import numpy as np  # ÊýÖµ¼ÆËã¿â
from datetime import datetime, timedelta  # ÈÕÆÚºÍÊ±¼ä´¦Àí
from threading import Thread  # ¶àÏß³ÌÖ§³Ö
from tkinter import Tk, Label, Button, Entry, StringVar, messagebox, BOTTOM, LEFT, Frame  # GUI×é¼þ
from tkinter import Toplevel  # ÔÚ¶¥²¿¼ÓÉÏ
import tkinter.font as tkFont  # Tkinter×ÖÌåÖ§³Ö
import os  # ²Ù×÷ÏµÍ³¹¦ÄÜ½Ó¿Ú
from PIL import Image, ImageTk  # Í¼Ïñ´¦Àí¿â£¬ÓÃÓÚTkinterÖÐÏÔÊ¾Í¼Ïñ
import sqlite3  # SQLiteÊý¾Ý¿âÖ§³Ö
import face_recognition  # ÈËÁ³Ê¶±ð¿â
import json  # JSONÊý¾Ý´¦Àí
from tkinter import ttk  # Tkinter¸ß¼¶×é¼þ
from pypinyin import lazy_pinyin  # ÖÐÎÄ×ªÆ´Òô¹¤¾ß
import requests  # HTTPÇëÇó¿â
from tqdm import tqdm  # ½ø¶ÈÌõÏÔÊ¾
import pandas as pd  # Êý¾Ý´¦Àí¿â£¬ÓÃÓÚµ¼³öCSV
import threading  # Ïß³Ì¹ÜÀí
import queue  # Ïß³Ì¼äÍ¨ÐÅ
import signal  # ÐÅºÅ´¦Àí
import torch.serialization  # Ìí¼Ó´ËÐÐ£¬ÓÃÓÚ´¦Àí°²È«¼ÓÔØ
import sys  # Ìí¼Ó´ËÐÐ£¬ÓÃÓÚÏµÍ³ÍË³ö¹¦ÄÜ

sys.path.append('/home/elf/.cache/torch/hub/ultralytics_yolov5_master')  # Â·¾¶¸ù¾ÝÄãµÄ»·¾³µ÷Õû

from models.experimental import attempt_load
from utils.general import non_max_suppression

# Ìæ»»YOLOv5ÍÆÀíÎªRKNN NPUÍÆÀí£¬ÒÆ³ýPyTorchÏà¹ØÄÚÈÝ
import os
os.environ['RKNN_LOG_LEVEL'] = 'ERROR'  # ÉèÖÃÈÕÖ¾¼¶±ðÎªERROR£¬±ÜÃâÊä³ö¹ý¶àÐÅÏ¢
from rknnlite.api import RKNNLite
from coco_utils import COCO_test_helper

# È«¾Ö±äÁ¿ÉùÃ÷£¬ÓÃÓÚ±¨¾¯´°¿Ú
alert_window = None
alert_label = None

def init_database():
    """³õÊ¼»¯Êý¾Ý¿â£¬´´½¨±ØÒªµÄ±í"""
    try:
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            
            # ´´½¨ÈËÁ³Êý¾Ý±í
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS face_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id TEXT UNIQUE,
                name TEXT,
                position TEXT,
                face_id TEXT UNIQUE,
                face_encoding TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            ''')
            # ´´½¨°²È«Ã±Î¥¹æ¼ÇÂ¼±í
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS helmet_violation_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id TEXT,
                name TEXT,
                violation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                image_path TEXT
            )
            ''')
            
            # ´´½¨Àë¸Ú¼ÇÂ¼±í
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS absence_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id TEXT,
                name TEXT,
                absence_duration TEXT,
                absence_date TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            ''')
            
            conn.commit()
            print("Database initialized successfully.")
    except sqlite3.Error as e:
        print(f"Database initialization error: {e}")


class HybridWorkerDetector:
    """»ìºÏ¹¤ÈË¼ì²âÆ÷,½áºÏHOGºÍYOLOv5"""
    
    def __init__(self, yolo_model_path ='/home/elf/reid_project/helmet_detection.pt' , face_library=None):
        self.yolo_model_path = yolo_model_path
        self.face_library = face_library or []
        self.yolo_model = None
        self.yolo_loaded = False
        self.yolo_loading = False
        self.detection_mode = "hog"  # ³õÊ¼Ê¹ÓÃHOG¼ì²âÆ÷
        
        # ³õÊ¼»¯HOGÐÐÈË¼ì²âÆ÷
        self.hog = cv2.HOGDescriptor()
        self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        print("[INFO] HOG pedestrian detector initialized")
        
        # Æô¶¯YOLOv5Ä£ÐÍÒì²½¼ÓÔØ
        self.start_yolo_loading()
    
    def start_yolo_loading(self):
        """Òì²½¼ÓÔØYOLOv5Ä£ÐÍ"""
        if self.yolo_loading or self.yolo_loaded:
            return
        
        self.yolo_loading = True
        Thread(target=self._load_yolo_model, daemon=True).start()
    
    def _load_yolo_model(self):
        """ÔÚºóÌ¨Ïß³ÌÖÐ¼ÓÔØYOLOv5°²È«Ã±¼ì²âÄ£ÐÍ£¬²¢Ìí¼ÓÄ£ÐÍÑéÖ¤"""
        try:
            print("[INFO] Starting to load YOLOv5 helmet model...")
            
            # ¼ÓÔØÄ£ÐÍ
            self.yolo_model = attempt_load('helmet_detection.pt')
            
            # ÑéÖ¤Ä£ÐÍÊÇ·ñ³É¹¦¼ÓÔØ
            if self.yolo_model is None:
                raise ValueError("Model loading returned None")
                
            # ÑéÖ¤Ä£ÐÍÊÇ·ñ¾ßÓÐ±ØÐèµÄÊôÐÔ
            if not hasattr(self.yolo_model, 'names') and not hasattr(self.yolo_model, 'module'):
                raise ValueError("Model missing required attributes (names or module)")
                
            # ÑéÖ¤Ä£ÐÍÍÆÀíÄÜÁ¦
            dummy_input = torch.randn(1, 3, 640, 640)  # ´´½¨ÐéÄâÊäÈë
            with torch.no_grad():
                try:
                    dummy_output = self.yolo_model(dummy_input)
                    if not isinstance(dummy_output, (tuple, list)) or len(dummy_output) == 0:
                        raise ValueError("Model inference failed - invalid output format")
                except Exception as infer_error:
                    raise ValueError(f"Model inference test failed: {str(infer_error)}")
            
            # Èç¹ûÍ¨¹ýËùÓÐÑéÖ¤£¬Ôò±ê¼ÇÎªÒÑ¼ÓÔØ
            self.yolo_loaded = True
            self.detection_mode = "hybrid"
            print("[INFO] YOLOv5 helmet model loaded and validated successfully, switched to hybrid detection mode")
            
        except Exception as e:
            print(f"[ERROR] YOLOv5 helmet model loading/validation failed: {e}")
            # È·±£×´Ì¬Ò»ÖÂÐÔ
            self.yolo_model = None
            self.yolo_loaded = False
        finally:
            self.yolo_loading = False
    
    def detect_workers(self, frame):
        """¼ì²â»­ÃæÖÐµÄ¹¤ÈË
        
        Args:
            frame: ÊäÈëÊÓÆµÖ¡
            
        Returns:
            worker_detected: ÊÇ·ñ¼ì²âµ½¹¤ÈË
            detections: ¼ì²âµ½µÄÈËÌåÎ»ÖÃÁÐ±í [(x1,y1,x2,y2), ...]
            frame: ´¦ÀíºóµÄÖ¡£¨´øÓÐ±ê×¢£©
        """
        # È·±£ÊäÈëÖ¡ÓÐÐ§
        if frame is None or frame.size == 0:
            return False, [], frame
        
        # ¸´ÖÆÒ»·ÝÖ¡ÓÃÓÚ»æÖÆ
        result_frame = frame.copy()
        all_detections = []
        worker_detected = False
        confidence_threshold = 0.5  # ÖÃÐÅ¶ÈãÐÖµ
        
        # Ê¹ÓÃHOG¼ì²âÆ÷
        hog_detections = self._detect_with_hog(frame)
        for (x, y, w, h) in hog_detections:
            all_detections.append((x, y, x+w, y+h, 0.6, "hog"))  # HOGÄ¬ÈÏÖÃÐÅ¶È0.6
            cv2.rectangle(result_frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(result_frame, "Person(HOG)", (x, y-10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        # Èç¹ûYOLOv5ÒÑ¼ÓÔØ£¬ÔòÈÚºÏ¼ì²â½á¹û
        if self.yolo_loaded and self.yolo_model is not None:
            try:
                # ×ª»»frameÎªTensor
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = img.transpose(2, 0, 1)
                img = np.ascontiguousarray(img)
                img = torch.from_numpy(img).float()
                img /= 255.0
                if img.ndimension() == 3:
                    img = img.unsqueeze(0)
                with torch.no_grad():
                    pred = self.yolo_model(img)[0]
                    pred = non_max_suppression(pred, conf_thres=0.25, iou_thres=0.45)[0]  # Ö»È¡µÚÒ»¸öbatch

                names = self.yolo_model.names if hasattr(self.yolo_model, 'names') else self.yolo_model.module.names

                if pred is not None and len(pred):
                    for *xyxy, conf, class_id in pred.cpu().numpy():
                        label = names[int(class_id)]
                        if label in ['helmet', 'with_helmet']:
                            color = (0, 255, 0)
                            text = "Helmet"
                        else:
                            color = (0, 0, 255)
                            text = "No Helmet"
                            violation_count += 1
                            # ÈËÁ³Ê¶±ð»ñÈ¡ÐÕÃû
                            try:
                                face_locations = face_recognition.face_locations(frame)
                                face_encodings = face_recognition.face_encodings(frame, face_locations)
                                name = "Unknown"
                                for face_encoding in face_encodings:
                                    for face_data in self.face_library:
                                        known_encoding = np.array(face_data["encoding"])
                                        matches = face_recognition.compare_faces([known_encoding], face_encoding)
                                        if matches[0]:
                                            name = face_data["name"]
                                            break

                            except Exception as e:
                                print(f"[ERROR] face_recognition error: {e}")
                                name = "Unknown"
                            record_helmet_violation("unknown", name)
                        cv2.rectangle(result_frame, (int(xyxy[0]), int(xyxy[1])), (int(xyxy[2]), int(xyxy[3])), color, 2)
                        cv2.putText(result_frame, text, (int(xyxy[0]), int(xyxy[1])-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
            except Exception as e:
                print(f"[ERROR] YOLOv5 detection error: {e}")
        
        # ·Ç¼«´óÖµÒÖÖÆ (NMS) ÈÚºÏÖØµþ¼ì²â
        if len(all_detections) > 1:
            # ÌáÈ¡×ø±êºÍÖÃÐÅ¶È
            boxes = np.array([[x1, y1, x2, y2] for (x1, y1, x2, y2, _, _) in all_detections])
            confidences = np.array([conf for (_, _, _, _, conf, _) in all_detections])
            
            # Ó¦ÓÃNMS
            indices = cv2.dnn.NMSBoxes(boxes.tolist(), confidences.tolist(), 0.5, 0.4).flatten()
            
            # ±£ÁôNMSºóµÄ¼ì²â½á¹û
            filtered_detections = [all_detections[i] for i in indices]
            all_detections = filtered_detections
        
        # »ùÓÚÈËÁ³Ê¶±ðÔöÇ¿¼ì²â
        if len(all_detections) > 0:
            worker_detected = True
            self._enhance_with_face_recognition(frame, result_frame, all_detections)
        
        # ·µ»Ø¼ì²â½á¹û
        return worker_detected, all_detections, result_frame
    
    def _detect_with_hog(self, frame):
        """Ê¹ÓÃHOG¼ì²âÆ÷¼ì²âÈËÌå"""
        # µ÷ÕûÍ¼Ïñ´óÐ¡ÒÔÌá¸ßÐÔÄÜ
        height, width = frame.shape[:2]
        
        # Èç¹ûÍ¼ÏñÌ«´ó£¬Ôòµ÷Õû´óÐ¡
        if width > 640:
            scale = 640.0 / width
            frame_resized = cv2.resize(frame, (640, int(height * scale)))
        else:
            scale = 1.0
            frame_resized = frame
        
        # HOG¼ì²â
        boxes, weights = self.hog.detectMultiScale(
            frame_resized, 
            winStride=(8, 8), 
            padding=(4, 4), 
            scale=1.05
        )
        
        # Èç¹û½øÐÐÁËËõ·Å£¬Ôò½«½á¹ûÓ³Éä»ØÔ­Ê¼³ß´ç
        if scale != 1.0:
            boxes = np.array([[int(x/scale), int(y/scale), int(w/scale), int(h/scale)] for (x, y, w, h) in boxes])
        
        return boxes
    
    def _enhance_with_face_recognition(self, frame, result_frame, detections):
        """Ê¹ÓÃÈËÁ³Ê¶±ðÔöÇ¿¼ì²â½á¹û"""
        if not self.face_library:
            return
        
        # ¼ì²âÈËÁ³
        face_locations = face_recognition.face_locations(frame)
        face_encodings = face_recognition.face_encodings(frame, face_locations)
        
        # »ñÈ¡ÈËÁ³ÌØÕ÷µã
        face_landmarks_list = face_recognition.face_landmarks(frame, face_locations)
        
        # Ê¶±ðÈËÁ³
        for face_encoding, (top, right, bottom, left), landmarks in zip(face_encodings, face_locations, face_landmarks_list):
            name = "Unknown"
            for face_data in self.face_library:
                known_encoding = np.array(face_data["encoding"])
                matches = face_recognition.compare_faces([known_encoding], face_encoding)
                if matches[0]:
                    name = face_data["name"]
                    break
            
            # ÖÐÎÄ×ªÆ´ÒôÏÔÊ¾
            display_name = " ".join(lazy_pinyin(name)) if name != "Unknown" else name
            
            # ÔÚÍ¼ÏñÉÏ»æÖÆÈËÁ³¿òºÍ±êÇ©
            cv2.rectangle(result_frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(result_frame, display_name, (left, top-10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            
            # ÏÔÊ¾ÈËÁ³ÌØÕ÷µã
            self._draw_facial_landmarks(result_frame, landmarks)

    def _draw_facial_landmarks(self, frame, landmarks, show_labels=False):
        """»æÖÆÈËÁ³ÌØÕ÷µãºÍÁ¬Ïß
        
        ²ÎÊý:
            frame: Òª»æÖÆµÄÍ¼ÏñÖ¡
            landmarks: ÈËÁ³ÌØÕ÷µã×Öµä
            show_labels: ÊÇ·ñÏÔÊ¾ÌØÕ÷±êÇ©£¬Ä¬ÈÏFalse
        """
        # »æÖÆ¸÷¸öÌØÕ÷µã
        for feature, points in landmarks.items():
            # ¸ù¾Ý²»Í¬ÌØÕ÷ÉèÖÃ²»Í¬ÑÕÉ«
            if feature == 'chin':  # ÏÂ°Í
                color = (255, 0, 0)  # À¶É«
                label = "Chin"
            elif feature == 'left_eye':  # ×óÑÛ
                color = (0, 255, 0)  # ÂÌÉ«
                label = "Left Eye"
            elif feature == 'right_eye':  # ÓÒÑÛ
                color = (0, 255, 0)  # ÂÌÉ«
                label = "Right Eye"
            elif feature == 'left_eyebrow':  # ×óÃ¼Ã«
                color = (255, 255, 0)  # ÇàÉ«
                label = "Left Eyebrow"
            elif feature == 'right_eyebrow':  # ÓÒÃ¼Ã«
                color = (255, 255, 0)  # ÇàÉ«
                label = "Right Eyebrow"
            elif feature == 'nose_bridge':  # ±ÇÁº
                color = (0, 0, 255)  # ºìÉ«
                label = "Nose Bridge"
            elif feature == 'nose_tip':  # ±Ç¼â
                color = (0, 0, 255)  # ºìÉ«
                label = "Nose Tip"
            elif feature == 'top_lip':  # ÉÏ×ì´½
                color = (255, 0, 255)  # ×ÏÉ«
                label = "Top Lip"
            elif feature == 'bottom_lip':  # ÏÂ×ì´½
                color = (255, 0, 255)  # ×ÏÉ«
                label = "Bottom Lip"
            else:
                color = (255, 255, 255)  # °×É«
                label = feature
            
            # »æÖÆÁ¬Ïß£¨½«µãÒÀ´ÎÁ¬½Ó£©
            prev_point = None
            for i, point in enumerate(points):
                # »æÖÆÌØÕ÷µã
                cv2.circle(frame, point, 2, color, -1)
                
                # Á¬½Óµã
                if prev_point is not None:
                    cv2.line(frame, prev_point, point, color, 1)
                prev_point = point
                
            # Èç¹ûÊÇ±Õ»·ÌØÕ÷£¨ÈçÑÛ¾¦¡¢×ì´½£©£¬ÔòÁ¬½ÓÊ×Î²µã
            if feature in ['left_eye', 'right_eye', 'top_lip', 'bottom_lip'] and len(points) > 2:
                cv2.line(frame, points[-1], points[0], color, 1)
            
            # ÏÔÊ¾ÌØÕ÷±êÇ©
            if show_labels and points:
                # Ñ¡ÔñÒ»¸öºÏÊÊµÄµãÀ´·ÅÖÃ±êÇ©
                label_point = points[0]  # Ê¹ÓÃµÚÒ»¸öµãµÄÎ»ÖÃ
                if feature == 'left_eye':
                    label_point = points[3]  # ×óÑÛÍâ²à
                elif feature == 'right_eye':
                    label_point = points[0]  # ÓÒÑÛÍâ²à
                
                # Ìí¼Ó±êÇ©ÎÄ±¾
                cv2.putText(frame, label, 
                           (label_point[0], label_point[1]-5), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.3, color, 1)

def check_face_exists(face_encoding, similarity_threshold=0.6):
    """
    ¼ì²éÈËÁ³ÊÇ·ñÒÑ´æÔÚÓÚÊý¾Ý¿âÖÐ
    
    ²ÎÊý:
        face_encoding: ´ý¼ì²éµÄÈËÁ³ÌØÕ÷ÏòÁ¿
        similarity_threshold: ÏàËÆ¶ÈãÐÖµ£¬Ä¬ÈÏ0.6
        
    ·µ»Ø:
        (bool, dict): (ÊÇ·ñ´æÔÚ, Æ¥ÅäµÄÈËÁ³Êý¾Ý)
    """
    try:
        # ´ÓÊý¾Ý¿â»ñÈ¡ËùÓÐÈËÁ³Êý¾Ý
        face_data_list = get_all_faces_from_db()
        
        # ¶Ô±ÈÃ¿Ò»¸öÒÑ´æÔÚµÄÈËÁ³
        for face_data in face_data_list:
            known_encoding = np.array(face_data["encoding"])
            # ¼ÆËãÅ·ÊÏ¾àÀë£¬¾àÀëÔ½Ð¡±íÊ¾Ô½ÏàËÆ
            face_distance = face_recognition.face_distance([known_encoding], face_encoding)
            
            # Èç¹û¾àÀëÐ¡ÓÚãÐÖµ£¬ÔòÈÏÎªÊÇÍ¬Ò»¸öÈË
            if face_distance[0] < similarity_threshold:
                return True, face_data
                
        return False, None
    except Exception as e:
        print(f"Error checking if face exists: {e}")
        return False, None

def save_face_to_db(employee_id, name, position, face_encoding):
    """±£´æÈËÁ³ÌØÕ÷µ½Êý¾Ý¿â
    
    ²ÎÊý:
        employee_id: Ô±¹¤ID
        name: Ô±¹¤ÐÕÃû
        position: Ö°Î»
        face_encoding: Ãæ²¿ÌØÕ÷ÏòÁ¿ (numpy array)
    
    ·µ»Ø:
        bool: ÊÇ·ñ±£´æ³É¹¦
    """
    try:
        face_id = f"face_{employee_id}"
        # ½«numpyÊý×é×ª»»ÎªJSON×Ö·û´®
        encoding_json = json.dumps(face_encoding.tolist())
        
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('''
            INSERT OR REPLACE INTO face_records
            (employee_id, name, position, face_id, face_encoding)
            VALUES (?, ?, ?, ?, ?)
            ''', (employee_id, name, position, face_id, encoding_json))
            conn.commit()
            print(f"Successfully saved face data to database: {name} ({employee_id})")
            return True
    except Exception as e:
        print(f"Failed to save face data: {e}")
        return False

def get_all_faces_from_db():
    """´ÓÊý¾Ý¿â»ñÈ¡ËùÓÐÈËÁ³Êý¾Ý
    
    ·µ»Ø:
        list: ÈËÁ³Êý¾ÝÁÐ±í
    """
    try:
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT employee_id, name, position, face_id, face_encoding FROM face_records')
            rows = cursor.fetchall()
            
            face_data_list = []
            for row in rows:
                employee_id, name, position, face_id, encoding_json = row
                # ½«JSON×Ö·û´®×ª»ØnumpyÊý×é
                try:
                    encoding = np.array(json.loads(encoding_json))
                    
                    face_data = {
                        "employee_id": employee_id,
                        "name": name,
                        "position": position,
                        "face_id": face_id,
                        "encoding": encoding
                    }
                    face_data_list.append(face_data)
                except json.JSONDecodeError as e:
                    print(f"Failed to parse face encoding: {e}, data: {encoding_json[:30]}...")
            
            print(f"Loaded {len(face_data_list)} face records from database")
            return face_data_list
    except Exception as e:
        print(f"Failed to get face data: {e}")
        return []

def migrate_json_to_db():
    """½«ÏÖÓÐJSONÎÄ¼þÊý¾ÝÇ¨ÒÆµ½Êý¾Ý¿â"""
    try:
        # È·±£ÈËÁ³¿âÄ¿Â¼´æÔÚ
        if not os.path.exists("face_library"):
            print("Face library directory doesn't exist, no migration needed")
            return
            
        # Ç¨ÒÆ¼ÆÊý
        migrated_count = 0
        failed_count = 0
        
        for file in os.listdir("face_library"):
            if file.endswith(".json"):
                try:
                    with open(os.path.join("face_library", file), "r") as f:
                        face_data = json.load(f)
                        
                    # ÌáÈ¡Êý¾Ý
                    employee_id = face_data.get("employee_id")
                    name = face_data.get("name")
                    position = face_data.get("position")
                    encoding = np.array(face_data.get("encoding"))
                    
                    # ±£´æµ½Êý¾Ý¿â
                    if save_face_to_db(employee_id, name, position, encoding):
                        migrated_count += 1
                    else:
                        failed_count += 1
                        
                except Exception as e:
                    print(f"Failed to migrate file {file}: {e}")
                    failed_count += 1
        
        print(f"Migration completed: {migrated_count} successful, {failed_count} failed")
    except Exception as e:
        print(f"Error during migration process: {e}")

def alert_popup_dynamic(message, parent=None):
    """
    ¶¯Ì¬¸üÐÂµÄ±¨¾¯µ¯´°º¯Êý£¨·Ç×èÈû£¬²»ÍË³öÖ÷¼ì²â£©
    ²ÎÊý:
        message (str): ÒªÏÔÊ¾µÄ±¨¾¯ÐÅÏ¢
        parent: Ö÷´°¿Ú
    """
    global alert_window, alert_label

    # ¼ì²é´°¿ÚÊÇ·ñÒÑ¾­´æÔÚ
    if alert_window is None or not alert_window.winfo_exists():
        # Èç¹û²»´æÔÚ£¬´´½¨Ò»¸öÐÂµÄToplevel´°¿Ú
        alert_window = Toplevel(parent)
        alert_window.title("Alert")
        alert_window.geometry("400x120+600+300")
        alert_window.attributes("-topmost", True)
        alert_window.resizable(False, False)
        # ´´½¨Ò»¸öÐÂµÄ±êÇ©£¬ÉèÖÃ×ÖÌåÎªArial£¬ÑÕÉ«ÎªºìÉ«
        alert_label = Label(alert_window, text=message, padx=20, pady=20, font=("Arial", 16), fg="red")
        alert_label.pack()
        # Ìí¼Ó¹Ø±Õ°´Å¥
        Button(alert_window, text="¹Ø±Õ", command=alert_window.destroy, font=("Arial", 12)).pack(pady=5)
    else:
        # Èç¹û´°¿ÚÒÑ´æÔÚ£¬Ôò¸üÐÂ±êÇ©µÄÎÄ±¾
        alert_label.config(text=message)
        alert_window.deiconify()
        alert_window.lift()
    # ²»µ÷ÓÃ mainloop£¬²»×èÈûÖ÷¼ì²â

def enroll_face(employee_id, name, position):
    """
    Â¼ÈëÈËÁ³²¢±£´æµ½Êý¾Ý¿â
    
    ²ÎÊý:
        employee_id (str): Ô±¹¤ID
        name (str): Ô±¹¤ÐÕÃû
        position (str): Ô±¹¤Ö°Î»
    """
    cap = cv2.VideoCapture(11)  # ³õÊ¼»¯ÉãÏñÍ·
    print("Please face the camera, press 'q' to complete enrollment")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Cannot read camera frame")
            break

        cv2.imshow("Face Enrollment", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            face_locations = face_recognition.face_locations(frame)
            if face_locations:
                face_encodings = face_recognition.face_encodings(frame, face_locations)
                if face_encodings:
                    # ±£´æµ½Êý¾Ý¿â
                    if save_face_to_db(employee_id, name, position, face_encodings[0]):
                        print(f"Face enrollment successful: {name} ({employee_id})")
                    else:
                        print("Database save failed, please try again")
                else:
                    print("Could not extract face features, please try again")
            else:
                print("No face detected, please try again")
            break

    cap.release()
    cv2.destroyAllWindows()

def download_model(model_url, save_path, timeout=60):
    """
    ÏÂÔØÄ£ÐÍÎÄ¼þ£¬²¢ÏÔÊ¾ÏÂÔØ½ø¶È
    
    ²ÎÊý:
        model_url (str): Ä£ÐÍÏÂÔØµØÖ·
        save_path (str): ±£´æÂ·¾¶
        timeout (int): ÏÂÔØ³¬Ê±Ê±¼ä£¬µ¥Î»Ãë£¬Ä¬ÈÏ 60 Ãë
    """
    try:
        print(f"[DEBUG] Starting model download: {model_url}")
        response = requests.get(model_url, stream=True, timeout=timeout)
        response.raise_for_status()

        # »ñÈ¡ÎÄ¼þ´óÐ¡
        total_size = int(response.headers.get('content-length', 0))
        
        # Èç¹ûÃ»ÓÐ content-length Í·£¬Ö±½ÓÏÂÔØ²¢±£´æ
        if (total_size == 0):
            with open(save_path, 'wb') as f:
                f.write(response.content)
            print(f"[DEBUG] Model download complete: {save_path}")
            return

        # Æô¶¯½ø¶ÈÌõ
        with open(save_path, 'wb') as f, tqdm(
                total=total_size, unit='B', unit_scale=True, desc=save_path.split('/')[-1]) as bar:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    bar.update(len(chunk))

        print(f"[DEBUG] Model download complete: {save_path}")
        
    except requests.exceptions.Timeout:
        print("[ERROR] Download timeout, please check network connection or increase timeout")
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Network request error: {e}")
    except Exception as e:
        print(f"[ERROR] Model download failed: {e}")

def record_absence(employee_id, name, absence_duration, absence_date):
    """¼ÇÂ¼Àë¸ÚÐÅÏ¢µ½Í³Ò»Êý¾Ý¿â"""
    try:
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('''
            INSERT INTO absence_records 
            (employee_id, name, absence_duration, absence_date)
            VALUES (?, ?, ?, ?)
            ''', (employee_id, name, absence_duration, absence_date))
            conn.commit()
            return True
    except Exception as e:
        print(f"[ERROR] Failed to record absence information: {e}")
        return False

def record_helmet_violation(employee_id, name, image_path=None):
    """¼ÇÂ¼Î´Åå´÷°²È«Ã±ÐÅÏ¢µ½Êý¾Ý¿â"""
    try:
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('''
            INSERT INTO helmet_violation_records (employee_id, name, image_path)
            VALUES (?, ?, ?)
            ''', (employee_id, name, image_path))
            conn.commit()
            return True
    except Exception as e:
        print(f"[ERROR] Failed to record helmet violation: {e}")
        return False

def filter_boxes(boxes, box_confidences, box_class_probs, obj_thresh):
    box_confidences = box_confidences.reshape(-1)
    class_max_score = np.max(box_class_probs, axis=-1)
    classes = np.argmax(box_class_probs, axis=-1)
    _class_pos = np.where(class_max_score * box_confidences >= obj_thresh)
    scores = (class_max_score * box_confidences)[_class_pos]
    boxes = boxes[_class_pos]
    classes = classes[_class_pos]
    return boxes, classes, scores

def nms_boxes(boxes, scores, nms_thresh):
    x = boxes[:, 0]
    y = boxes[:, 1]
    w = boxes[:, 2] - boxes[:, 0]
    h = boxes[:, 3] - boxes[:, 1]
    areas = w * h
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        xx1 = np.maximum(0, x[i] - w[i] / 2)
        yy1 = np.maximum(0, y[i] - h[i] / 2)
        xx2 = np.minimum(x[i] + w[i] / 2, x[order[1:]] + w[order[1:]] / 2)
        yy2 = np.minimum(y[i] + h[i] / 2, y[order[1:]] + h[order[1:]] / 2)
        w1 = np.maximum(0.0, xx2 - xx1 + 0.00001)
        h1 = np.maximum(0.0, yy2 - yy1 + 0.00001)
        inter = w1 * h1
        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        inds = np.where(ovr <= nms_thresh)[0]
        order = order[inds + 1]
    return np.array(keep)

def box_process(position, anchors):
    grid_h, grid_w = position.shape[2:4]
    col, row = np.meshgrid(np.arange(0, grid_w), np.arange(0, grid_h))
    col = col.reshape(1, 1, grid_h, grid_w)
    row = row.reshape(1, 1, grid_h, grid_w)
    grid = np.concatenate((col, row), axis=1)
    stride = np.array([IMG_SIZE[1] // grid_h, IMG_SIZE[0] // grid_w]).reshape(1, 2, 1, 1)
    col = col.repeat(len(anchors), axis=0)
    row = row.repeat(len(anchors), axis=0)
    anchors = np.array(anchors)
    anchors = anchors.reshape(*anchors.shape, 1, 1)
    box_xy = position[:, :2, :, :] * 2 - 0.5
    box_wh = pow(position[:, 2:4, :, :] * 2, 2) * anchors
    box_xy += grid
    box_xy *= stride
    box = np.concatenate((box_xy, box_wh), axis=1)
    xyxy = np.copy(box)
    xyxy[:, 0, :, :] = box[:, 0, :, :] - box[:, 2, :, :] / 2
    xyxy[:, 1, :, :] = box[:, 1, :, :] - box[:, 3, :, :] / 2
    xyxy[:, 2, :, :] = box[:, 0, :, :] + box[:, 2, :, :] / 2
    xyxy[:, 3, :, :] = box[:, 1, :, :] + box[:, 3, :, :] / 2
    return xyxy

def post_process(input_data, anchors):
    boxes, scores, classes_conf = [], [], []
    input_data = [_in.reshape([len(anchors[0]), -1] + list(_in.shape[-2:])) for _in in input_data]
    for i in range(len(input_data)):
        boxes.append(box_process(input_data[i][:, :4, :, :], anchors[i]))
        scores.append(input_data[i][:, 4:5, :, :])
        classes_conf.append(input_data[i][:, 5:, :, :])
    def sp_flatten(_in):
        ch = _in.shape[1]
        _in = _in.transpose(0, 2, 3, 1)
        return _in.reshape(-1, ch)
    boxes = [sp_flatten(_v) for _v in boxes]
    classes_conf = [sp_flatten(_v) for _v in classes_conf]
    scores = [sp_flatten(_v) for _v in scores]
    boxes = np.concatenate(boxes)
    classes_conf = np.concatenate(classes_conf)
    scores = np.concatenate(scores)
    boxes, classes, scores = filter_boxes(boxes, scores, classes_conf, OBJ_THRESH)
    if len(boxes) == 0:
        return None, None, None
    nboxes, nclasses, nscores = [], [], []
    for c in set(classes):
        inds = np.where(classes == c)
        b = boxes[inds]
        c = classes[inds]
        s = scores[inds]
        keep = nms_boxes(b, s, NMS_THRESH)
        if len(keep) != 0:
            nboxes.append(b[keep])
            nclasses.append(c[keep])
            nscores.append(s[keep])
    if not nclasses and not nscores:
        return None, None, None
    boxes = np.concatenate(nboxes)
    classes = np.concatenate(nclasses)
    scores = np.concatenate(nscores)
    return boxes, classes, scores

def draw_box_corner(draw_img, top, left, right, bottom, length, corner_color):
    cv2.line(draw_img, (top, left), (top + length, left), corner_color, thickness=3)
    cv2.line(draw_img, (top, left), (top, left + length), corner_color, thickness=3)
    cv2.line(draw_img, (right, left), (right - length, left), corner_color, thickness=3)
    cv2.line(draw_img, (right, left), (right, left + length), corner_color, thickness=3)
    cv2.line(draw_img, (top, bottom), (top + length, bottom), corner_color, thickness=3)
    cv2.line(draw_img, (top, bottom), (top, bottom - length), corner_color, thickness=3)
    cv2.line(draw_img, (right, bottom), (right - length, bottom), corner_color, thickness=3)
    cv2.line(draw_img, (right, bottom), (right, bottom - length), corner_color, thickness=3)

def draw_label_type(draw_img, top, left, label, label_color):
    labelSize = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
    if left - labelSize[1] - 3 < 0:
        box_coords = (top, left + 5, top + labelSize[0], left + labelSize[1] + 3)
        text_pos = (top, left + labelSize[0] + 3)
    else:
        box_coords = (top, left - labelSize[1] - 3, top + labelSize[0], left - 3)
        text_pos = (top, left - 3)
    cv2.rectangle(draw_img, box_coords[0:2], box_coords[2:4], color=label_color, thickness=-1)
    cv2.putText(draw_img, label, text_pos, cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), thickness=2)

def draw(image, boxes, scores, classes, classes_list):
    for box, score, cl in zip(boxes, scores, classes):
        top, left, right, bottom = [int(_b) for _b in box]
        cv2.rectangle(image, (top, left), (right, bottom), (255, 0, 255), 2)
        draw_box_corner(image, top, left, right, bottom, 15, (0, 255, 0))
        draw_label_type(image, top, left, f"{classes_list[cl]} {score:.2f}", (255, 0, 255))

def monitor_worker():
    """ÊµÊ±¼à²â°²È«Ã±Åå´÷Çé¿ö£¨RKNN NPU°æ±¾£©"""
    from collections import deque
    fps_queue = deque(maxlen=20)
    face_library = get_all_faces_from_db()
    if not face_library:
        print("[WARNING] Face library is empty, unable to identify worker identities")

    # RKNNÄ£ÐÍÂ·¾¶
    model_path = 'head_helmet_rk3588_i8.rknn'  # RKNNÄ£ÐÍ
    global OBJ_THRESH, NMS_THRESH, IMG_SIZE
    OBJ_THRESH = 0.5
    NMS_THRESH = 0.5
    IMG_SIZE = (640, 640)
    CLASSES = ("head", "helmet")
    ANCHORS = [
        [[10.0, 13.0], [16.0, 30.0], [33.0, 23.0]],
        [[30.0, 61.0], [62.0, 45.0], [59.0, 119.0]],
        [[116.0, 90.0], [156.0, 198.0], [373.0, 326.0]]
    ]

    # ³õÊ¼»¯RKNN
    rknn = RKNNLite(verbose=0)
    ret = rknn.load_rknn(model_path)
    if ret != 0:
        print('¼ÓÔØÄ£ÐÍÊ§°Ü£¡')
        return
    # Ê¹ÓÃrk3588µÄÈý¸öNPU½øÐÐÍÆÀí¼ÓËÙ
    ret = rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0_1_2)
    if ret != 0:
        ret = rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0)
        if ret != 0:
            ret = rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_AUTO)
            if ret != 0:
                print('³õÊ¼»¯ÔËÐÐÊ±»·¾³Ê§°Ü£¡')
                return

    cap = cv2.VideoCapture(11)
    if not cap.isOpened():
        print("Cannot open camera")
        return

    root = Tk()
    root.title("Helmet Detection Monitoring (RKNN)")
    root.geometry("900x750")
    font = set_english_font()

    info_label = Label(root, text="Status: Initializing...", font=font)
    info_label.pack(pady=5)
    mode_label = Label(root, text="Detection Mode: RKNN", font=font)
    mode_label.pack(pady=5)

    video_label = Label(root)
    video_label.pack(fill="both", expand=True)

    
    violation_label = Label(root, text="Helmet Violations: 0", font=font, fg="red")
    violation_label.pack(pady=5)

    update_id = None
    co_helper = COCO_test_helper(enable_letter_box=True)

    def update_frame():
        nonlocal update_id
        ret, frame = cap.read()
        if not ret:
            update_id = root.after(10, update_frame)
            return
        if not (isinstance(frame, np.ndarray) and frame.dtype == np.uint8):
            print("[ERROR] Invalid frame type")
            update_id = root.after(10, update_frame)
            return
        start_time = time.time()
        violation_count = 0
        detected_names = []
        result_frame = frame.copy()
        # RKNNÍÆÀí
        img = co_helper.letter_box(im=frame.copy(), new_shape=(IMG_SIZE[1], IMG_SIZE[0]), pad_color=(0, 0, 0))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = np.expand_dims(img, axis=0)
        outputs = rknn.inference(inputs=[img], data_format=['nhwc'])
        if outputs is not None:
            boxes, classes, scores = post_process(outputs, ANCHORS)
            if boxes is not None:
                boxes = co_helper.get_real_box(boxes)
                for box, score, cl in zip(boxes, scores, classes):
                    label = CLASSES[cl]
                    if label == 'helmet':
                        color = (0, 255, 0)
                        text = "Helmet"
                    else:
                        color = (0, 0, 255)
                        text = "No Helmet"
                        violation_count += 1
                        # ÈËÁ³Ê¶±ð»ñÈ¡ÐÕÃû
                        try:
                            face_locations = face_recognition.face_locations(frame)
                            face_encodings = face_recognition.face_encodings(frame, face_locations)
                            name = "Unknown"
                            for face_encoding in face_encodings:
                                for face_data in face_library:
                                    known_encoding = np.array(face_data["encoding"])
                                    matches = face_recognition.compare_faces([known_encoding], face_encoding)
                                    if matches[0]:
                                        name = face_data["name"]
                                        break
                                detected_names.append(name)
                        except Exception as e:
                            print(f"[ERROR] face_recognition error: {e}")
                            name = "Unknown"
                        record_helmet_violation("unknown", name)
                    x1, y1, x2, y2 = [int(_b) for _b in box]
                    cv2.rectangle(result_frame, (x1, y1), (x2, y2), color, 2)
                    cv2.putText(result_frame, text, (x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        info_label.config(text=f"Status: Helmet Detection Running")
        mode_label.config(text=f"Detection Mode: RKNN")
        violation_label.config(text=f"Helmet Violations: {violation_count}", fg="red" if violation_count > 0 else "green")
        if violation_count > 0:
            message = f"Detected {violation_count} person(s) without helmet!"
            # Ö»µ¯´°£¬²»ÍË³öÖ÷¼ì²â
            alert_popup_dynamic(message, parent=root)
        end_time = time.time()
        frame_fps = 1.0 / (end_time - start_time) if (end_time - start_time) > 0 else 0
        fps_queue.append(frame_fps)
        avg_fps = sum(fps_queue) / len(fps_queue) if fps_queue else 0
        cv2.putText(result_frame, f"FPS: {avg_fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        result_frame = cv2.cvtColor(result_frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(result_frame)
        imgtk = ImageTk.PhotoImage(image=img)
        video_label.imgtk = imgtk
        video_label.configure(image=imgtk)
        update_id = root.after(10, update_frame)

    Button(root, text="Return to Main Menu", command=lambda: [
        root.after_cancel(update_id) if update_id else None,
        cap.release(),
        root.destroy(),
        main_menu()
    ], font=font).pack(pady=10)

    update_id = root.after(10, update_frame)
    root.mainloop()
    cap.release()
    cv2.destroyAllWindows()
    rknn.release()

def create_face_enrollment_page():
    """´´½¨ÈËÁ³Â¼ÈëÒ³Ãæ£¨´°¿Ú¸ß¶È800£¬±í¸ñÇøÏÞ¸ß£¬°´Å¥ÇøÊ¼ÖÕ¿É¼û£©"""
    root = Tk()
    root.title("Face Enrollment")
    root.minsize(700, 800)  # ÉèÖÃ¸ü¸ßµÄ×îÐ¡¸ß¶È
    font = set_english_font()

    # ===== ÊäÈëÇøºáÅÅ =====
    input_frame = Frame(root)
    input_frame.pack(side="top", pady=10, fill="x")
    employee_id_var = StringVar()
    name_var = StringVar()
    position_var = StringVar()
    Label(input_frame, text="Employee ID:", font=font).pack(side=LEFT, padx=3)
    Entry(input_frame, textvariable=employee_id_var, font=font, width=10).pack(side=LEFT, padx=3)
    Label(input_frame, text="Name:", font=font).pack(side=LEFT, padx=3)
    Entry(input_frame, textvariable=name_var, font=font, width=10).pack(side=LEFT, padx=3)
    Label(input_frame, text="Position:", font=font).pack(side=LEFT, padx=3)
    Entry(input_frame, textvariable=position_var, font=font, width=10).pack(side=LEFT, padx=3)

    # ===== ×´Ì¬±êÇ© =====
    status_var = StringVar()
    status_var.set("Ready")
    status_label = Label(root, textvariable=status_var, font=font, fg="blue")
    status_label.pack(side="top", pady=2)

    # ===== ÊÓÆµºÍ±í¸ñÖ÷Çø =====
    center_frame = Frame(root, height=600)
    center_frame.pack_propagate(False)
    center_frame.pack(side="top", fill="both", expand=True)
    # ÊÓÆµÇøÏÞ¸ß£¨¼õÐ¡¸ß¶È£©
    video_frame = Frame(center_frame, height=320, width=680)
    video_frame.pack_propagate(False)
    video_frame.pack(side="top", pady=2, fill="x")
    video_label = Label(video_frame)
    video_label.pack(fill="both", expand=True)
    # ±í¸ñÇøÏÞ¸ß£¨×î¶àÏÔÊ¾2ÐÐ£©
    columns = ("Employee ID", "Name", "Position", "Face ID")
    table = ttk.Treeview(center_frame, columns=columns, show="headings", height=3)
    for col in columns:
        table.heading(col, text=col)
    table.pack(pady=2, fill="x", expand=False)

    # ===== °´Å¥Çø½ô¸ú±í¸ñÇø =====
    button_frame = Frame(center_frame, bg="#e0e0e0")
    button_frame.pack(side="top", fill="x", pady=18)
    enroll_button = Button(button_frame, text="Enroll", font=font, state="disabled", bg="#4caf50", fg="white")
    enroll_button.pack(side=LEFT, padx=30, pady=12)
    Button(button_frame, text="Return to Main Menu", font=font, bg="#2196f3", fg="white",
           command=lambda: [root.after_cancel(update_id) if update_id else None, cap.release(), root.destroy(), main_menu()]
    ).pack(side=LEFT, padx=30, pady=12)

    # ³õÊ¼»¯ÉãÏñÍ·
    cap = cv2.VideoCapture(11)
    current_face_encoding = None
    update_id = None

    def update_frame():
        nonlocal current_face_encoding, update_id
        ret, frame = cap.read()
        if not ret:
            update_id = root.after(10, update_frame)
            return
        face_locations = face_recognition.face_locations(frame)
        if face_locations:
            face_encodings = face_recognition.face_encodings(frame, face_locations)
            if face_encodings:
                current_face_encoding = face_encodings[0]
                exists, existing_face = check_face_exists(current_face_encoding)
                if exists:
                    status_var.set(f"Warning: Face already enrolled! Name: {existing_face['name']}, ID: {existing_face['employee_id']}")
                    status_label.config(fg="red")
                else:
                    status_var.set("Face detected, ready to enroll")
                    status_label.config(fg="green")
            face_landmarks_list = face_recognition.face_landmarks(frame, face_locations)
            for (top, right, bottom, left), landmarks in zip(face_locations, face_landmarks_list):
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                for feature, points in landmarks.items():
                    if feature == 'chin':
                        color = (255, 0, 0)
                    elif feature in ['left_eye', 'right_eye']:
                        color = (0, 255, 0)
                    elif feature in ['left_eyebrow', 'right_eyebrow']:
                        color = (255, 255, 0)
                    elif feature == 'nose_bridge' or feature == 'nose_tip':
                        color = (0, 0, 255)
                    elif feature == 'top_lip' or feature == 'bottom_lip':
                        color = (255, 0, 255)
                    else:
                        color = (255, 255, 255)
                    for point in points:
                        cv2.circle(frame, point, 1, color, -1)
                cv2.putText(frame, "Press 'Enroll' button to save face", (left, top - 10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        else:
            current_face_encoding = None
            status_var.set("No face detected, please face the camera")
            status_label.config(fg="blue")
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        imgtk = ImageTk.PhotoImage(image=img)
        video_label.imgtk = imgtk
        video_label.configure(image=imgtk)
        update_id = root.after(10, update_frame)

    def validate_inputs(*args):
        employee_id = employee_id_var.get()
        name = name_var.get()
        position = position_var.get()
        if employee_id and name and position:
            enroll_button.config(state="normal")
        else:
            enroll_button.config(state="disabled")

    def start_enrollment():
        nonlocal current_face_encoding
        if current_face_encoding is None:
            messagebox.showerror("Error", "No face detected, please face the camera and try again")
            return
        employee_id = employee_id_var.get()
        name = name_var.get()
        position = position_var.get()
        exists, existing_face = check_face_exists(current_face_encoding)
        if exists:
            messagebox.showwarning("Warning", f"This face is already enrolled!\nName: {existing_face['name']}\nID: {existing_face['employee_id']}")
            return
        if save_face_to_db(employee_id, name, position, current_face_encoding):
            messagebox.showinfo("Success", f"Successfully enrolled face data for {name}")
            for row in table.get_children():
                table.delete(row)
            with sqlite3.connect('worker_monitoring.db') as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT employee_id, name, position, face_id FROM face_records')
                rows = cursor.fetchall()
                for row in rows:
                    table.insert("", "end", values=row)
            employee_id_var.set("")
            name_var.set("")
            position_var.set("")
            status_var.set("Enrollment successful! Continue to enroll new faces")
            status_label.config(fg="green")
        else:
            messagebox.showerror("Error", "Database save failed, please try again")

    employee_id_var.trace_add("write", validate_inputs)
    name_var.trace_add("write", validate_inputs)
    position_var.trace_add("write", validate_inputs)
    enroll_button.config(command=start_enrollment)

    # ¼ÓÔØÏÖÓÐÈËÁ³Êý¾Ý
    try:
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT employee_id, name, position, face_id FROM face_records')
            rows = cursor.fetchall()
            for row in rows:
                table.insert("", "end", values=row)
    except Exception as e:
        print(f"Failed to load existing face data: {e}")

    update_id = root.after(10, update_frame)
    root.mainloop()

def create_monitoring_page():
    """´´½¨Àë¸Ú¼ì²âÒ³Ãæ"""
    monitor_worker()

def create_data_management_page():
    """
    ´´½¨Êý¾Ý¹ÜÀíÒ³Ãæ£¬Ìá¹©Êý¾Ý¿â²Ù×÷¹¦ÄÜ
    """
    root = Tk()
    root.title("Data Management")
    root.geometry("800x600")
    font = set_english_font()
    
    Label(root, text="Worker Data Management", font=tkFont.Font(family="Arial", size=16)).pack(pady=10)
    
    # ´´½¨Ñ¡Ïî¿¨
    tab_control = ttk.Notebook(root)
    tab1 = ttk.Frame(tab_control)
    tab2 = ttk.Frame(tab_control)
    tab3 = ttk.Frame(tab_control)
    tab4 = ttk.Frame(tab_control)
    tab_control.add(tab4, text='Helmet Violations')
    tab_control.pack(expand=1, fill="both")
    
    # ÈËÁ³Êý¾ÝÑ¡Ïî¿¨
    def load_face_data():
        # Çå¿Õ±í¸ñ
        for row in face_table.get_children():
            face_table.delete(row)
            
        # ´ÓÊý¾Ý¿â¼ÓÔØÊý¾Ý
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT employee_id, name, position, face_id FROM face_records')
            rows = cursor.fetchall()
            
            for row in rows:
                face_table.insert("", "end", values=row)
    
    def delete_face_record():
        selected = face_table.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a record to delete")
            return
            
        if messagebox.askyesno("Confirm", "Are you sure you want to delete the selected record(s)?"):
            for item in selected:
                employee_id = face_table.item(item, "values")[0]
                
                # ´ÓÊý¾Ý¿âÉ¾³ý
                with sqlite3.connect('worker_monitoring.db') as conn:
                    cursor = conn.cursor()
                    cursor.execute('DELETE FROM face_records WHERE employee_id = ?', (employee_id,))
                    conn.commit()
                
                # ´Ó±í¸ñÉ¾³ý
                face_table.delete(item)
    
    # ´´½¨ÈËÁ³Êý¾Ý±í¸ñ
    columns = ("Employee ID", "Name", "Position", "Face ID")
    face_table = ttk.Treeview(tab1, columns=columns, show="headings")
    for col in columns:
        face_table.heading(col, text=col)
    face_table.pack(pady=10, fill="both", expand=True)
    
    # Ìí¼Ó°´Å¥
    button_frame = Frame(tab1)
    button_frame.pack(pady=10)
    
    Button(button_frame, text="Refresh", command=load_face_data, font=font).pack(side=LEFT, padx=5)
    Button(button_frame, text="Delete", command=delete_face_record, font=font).pack(side=LEFT, padx=5)
    
    # Àë¸Ú¼ÇÂ¼Ñ¡Ïî¿¨
    def load_absence_data():
        # Çå¿Õ±í¸ñ
        for row in absence_table.get_children():
            absence_table.delete(row)
            
        # ´ÓÊý¾Ý¿â¼ÓÔØÊý¾Ý
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT employee_id, name, absence_date, absence_duration FROM absence_records ORDER BY absence_date DESC')
            rows = cursor.fetchall()
            
            for row in rows:
                absence_table.insert("", "end", values=row)
    
    # ´´½¨Àë¸Ú¼ÇÂ¼±í¸ñ
    columns = ("Employee ID", "Name", "Absence Date", "Absence Duration")
    absence_table = ttk.Treeview(tab2, columns=columns, show="headings")
    for col in columns:
        absence_table.heading(col, text=col)
    absence_table.pack(pady=10, fill="both", expand=True)
    
    # Ìí¼Ó°´Å¥
    button_frame2 = Frame(tab2)
    button_frame2.pack(pady=10)
    
    Button(button_frame2, text="Refresh", command=load_absence_data, font=font).pack(side=LEFT, padx=5)
    Button(button_frame2, text="Export CSV", command=lambda: export_to_csv("absence_records"), font=font).pack(side=LEFT, padx=5)
    
    # Êý¾Ýµ¼Èë/µ¼³öÑ¡Ïî¿¨
    Label(tab3, text="Data Migration Tools", font=font).pack(pady=10)
    
    Button(tab3, text="Import JSON Files to Database", command=migrate_json_to_db, font=font).pack(pady=10)
    Button(tab3, text="Export Face Data to JSON", command=lambda: export_to_json("face_records"), font=font).pack(pady=10)
    Button(tab3, text="Backup Entire Database", command=backup_database, font=font).pack(pady=10)
    
    # Helmet violation table
    columns = ("ID", "Employee ID", "Name", "Violation Time", "Image Path")
    helmet_table = ttk.Treeview(tab4, columns=columns, show="headings")
    for col in columns:
        helmet_table.heading(col, text=col)
    helmet_table.pack(pady=10, fill="both", expand=True)

    def load_helmet_data():
        for row in helmet_table.get_children():
            helmet_table.delete(row)
        with sqlite3.connect('worker_monitoring.db') as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT id, employee_id, name, violation_time, image_path FROM helmet_violation_records ORDER BY violation_time DESC')
            rows = cursor.fetchall()
            for row in rows:
                helmet_table.insert("", "end", values=row)

    def export_helmet_to_excel():
        try:
            with sqlite3.connect('worker_monitoring.db') as conn:
                df = pd.read_sql_query("SELECT * FROM helmet_violation_records", conn)
            filename = f"helmet_violations_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            df.to_excel(filename, index=False)
            messagebox.showinfo("Success", f"Data exported to {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Error: {e}")

    button_frame4 = Frame(tab4)
    button_frame4.pack(pady=10)
    Button(button_frame4, text="Refresh", command=load_helmet_data, font=font).pack(side=LEFT, padx=5)
    Button(button_frame4, text="Export Excel", command=export_helmet_to_excel, font=font).pack(side=LEFT, padx=5)
    load_helmet_data()

    # ¼ÓÔØ³õÊ¼Êý¾Ý
    load_face_data()
    load_absence_data()
    
    # ·µ»Ø°´Å¥
    Button(root, text="Return to Main Menu", command=lambda: [root.destroy(), main_menu()], font=font).pack(pady=10)
    
    root.mainloop()

def export_to_csv(table_name):
    """µ¼³ö±íÊý¾Ýµ½CSVÎÄ¼þ"""
    try:
        with sqlite3.connect('worker_monitoring.db') as conn:
            df = pd.read_sql_query(f"SELECT * FROM {table_name}", conn)
        
        filename = f"{table_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        df.to_csv(filename, index=False)
        messagebox.showinfo("Success", f"Data exported to {filename}")
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

def export_to_json(table_name):
    """µ¼³ö±íÊý¾Ýµ½JSONÎÄ¼þ"""
    try:
        filename = f"{table_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        if (table_name == "face_records"):
            # µ¼³öÈËÁ³Êý¾Ý
            face_data_list = get_all_faces_from_db()
            
            # ½«numpyÊý×é×ª»»ÎªÁÐ±íÒÔ±ãÐòÁÐ»¯
            for face_data in face_data_list:
                face_data["encoding"] = face_data["encoding"].tolist()
            
            with open(filename, "w") as f:
                json.dump(face_data_list, f, indent=2)
        else:
            # µ¼³öÆäËû±í
            with sqlite3.connect('worker_monitoring.db') as conn:
                df = pd.read_sql_query(f"SELECT * FROM {table_name}", conn)
                df.to_json(filename, orient="records", indent=2)
        
        messagebox.showinfo("Success", f"Data exported to {filename}")
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

def backup_database():
    """±¸·ÝÕû¸öÊý¾Ý¿â"""
    try:
        backup_file = f"worker_monitoring_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        
        with sqlite3.connect('worker_monitoring.db') as conn:
            # ´´½¨±¸·ÝÁ¬½Ó
            backup_conn = sqlite3.connect(backup_file)
            conn.backup(backup_conn)
            backup_conn.close()
            
        messagebox.showinfo("Success", f"Database backed up to {backup_file}")
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

def exit_system(root=None):
    """
    ÍêÈ«ÍË³öÏµÍ³£¬È·±£ÊÍ·ÅËùÓÐ×ÊÔ´
    
    ²ÎÊý:
        root: Tkinter¸ù´°¿Ú£¬Èç¹ûÌá¹©ÔòÏú»Ù
    """
    # ¹Ø±Õ¿ÉÄÜ´æÔÚµÄÈÎºÎ±¨¾¯´°¿Ú
    global alert_window
    if (alert_window is not None and alert_window.winfo_exists()):
        alert_window.destroy()
    
    # ³¢ÊÔ¹Ø±ÕÈÎºÎ¿ÉÄÜ´ò¿ªµÄÉãÏñÍ·
    try:
        # ÁÐ³öËùÓÐ¿ÉÄÜ´ò¿ªµÄÉãÏñÍ·
        for i in range(12):  # ³¢ÊÔ¹Ø±Õ0-11ºÅÉãÏñÍ·
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                cap.release()
    except Exception as e:
        print(f"Warning during camera cleanup: {e}")
    
    # ¹Ø±ÕËùÓÐOpenCV´°¿Ú
    cv2.destroyAllWindows()
    
    # Ïú»Ùµ±Ç°´°¿Ú
    if root is not None and root.winfo_exists():
        root.destroy()
    
    print("Exiting Worker Monitoring System...")
    
    # ÍêÈ«ÍË³ö³ÌÐò
    sys.exit(0)

def set_english_font():
    """·µ»ØÒ»¸ö±ê×¼µÄTkinter×ÖÌå¶ÔÏó"""
    return tkFont.Font(family="Arial", size=12)

def main_menu():
    """Ö÷²Ëµ¥Ò³Ãæ"""
    root = Tk()
    root.title("Worker Absence Monitoring - Hybrid Mode")
    root.geometry("400x550")
    
    font = set_english_font()
    
    # È·±£Êý¾Ý¿â³õÊ¼»¯
    init_database()
    
    Label(root, text="Worker Absence Monitoring", font=tkFont.Font(family="Arial", size=18)).pack(pady=20)
    Label(root, text="HOG + YOLOv5 Hybrid Detection", font=tkFont.Font(family="Arial", size=12)).pack(pady=5)
    
    Button(root, text="Face Enrollment", command=lambda: [root.destroy(), create_face_enrollment_page()], font=font).pack(pady=15)
    Button(root, text="Absence Monitoring", command=lambda: [root.destroy(), create_monitoring_page()], font=font).pack(pady=15)
    Button(root, text="Data Management", command=lambda: [root.destroy(), create_data_management_page()], font=font).pack(pady=15)
    
    # ÐÞ¸ÄÍË³ö°´Å¥£¬Ê¹ÓÃÐÂµÄexit_systemº¯Êý
    Button(root, text="Exit System", command=lambda: exit_system(root), font=font).pack(pady=15)
    
    # °æ±¾ºÍ°æÈ¨ÐÅÏ¢
    version_label = Label(root, text="Version: v1.1 - Hybrid Detection Enhanced", font=("Arial", 8))
    version_label.pack(side=BOTTOM, pady=5)
    copyright_label = Label(root, text="? 2025 Embedded AI Specialty", font=("Arial", 8))
    copyright_label.pack(side=BOTTOM)
    
    # Ìí¼Ó´°¿Ú¹Ø±ÕÊÂ¼þ´¦Àí
    root.protocol("WM_DELETE_WINDOW", lambda: exit_system(root))
    
    root.mainloop()

if __name__ == "__main__":
    # È·±£Êý¾Ý¿â³õÊ¼»¯
    init_database()
    
    # ×Ô¶¯Ö´ÐÐJSONµ½Êý¾Ý¿âµÄÇ¨ÒÆ£¨½öÊ×´ÎÔËÐÐ£©
    if os.path.exists("face_library") and not os.path.exists(".migration_completed"):
        migrate_json_to_db()
        # ±ê¼ÇÇ¨ÒÆÒÑÍê³É
        with open(".migration_completed", "w") as f:
            f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    
    main_menu()
